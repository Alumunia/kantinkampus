<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class portofolioModel extends Model {

    //
    protected $table = 'portofolioTable';

}
